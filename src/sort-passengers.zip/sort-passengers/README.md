Implementa el método sortPassengers(passengers) de forma que devuelva los mismos strings pero ordenados conforme a las siguientes reglas:
 
El parámetro passengers es un array de strings.
Los strings que forman parte del input passengers siguen el formato name-passengerType-checkInTimestamp
Hay 2 tipos de pasajero: BUSINESS y ECONOMY
Los pasajeros de tipo BUSINESS tienen que ser devueltos primero, en el orden original en el que aparecían.
Los pasajeros de tipo ECONOMY tienen que ser devueltos al final, ordenados por el timestamp de check in. Está garantizado que no hay timestamps de check in duplicados en la lista de pasajeros.
 
EJEMPLO
Input:
"Luisa Diaz-BUSINESS-1579188410"
"Juan Romero-ECONOMY-1579188430"
"Camila Greco-ECONOMY-1579188420"
"Mariano Camareli-BUSINESS-1579188440"
 
Output:
"Luisa Diaz-BUSINESS-1579188410"
"Mariano Camareli-BUSINESS-1579188440"
"Camila Greco-ECONOMY-1579188420"
"Juan Romero-ECONOMY-1579188430"