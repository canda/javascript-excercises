const parsePassenger = (passenger) => {
  const [name, type, timestamp] = passenger.split('-');
  return { name, type, timestamp };
};

const sortPassengers = (passengers) => {
  const business = passengers.filter(
    (p) => parsePassenger(p).type === 'BUSINESS',
  );
  const economy = passengers.filter(
    (p) => parsePassenger(p).type === 'ECONOMY',
  );

  return [
    ...business,
    ...economy.sort(
      (p1, p2) => parsePassenger(p1).timestamp - parsePassenger(p2).timestamp,
    ),
  ];
};

export default sortPassengers;
