import sortPassengers from './sort-passengers';

describe('sortPassengers', () => {
  it('should sort business first', () => {
    const passengers = [
      'Juan Romero-ECONOMY-1579188430',
      'Luisa Diaz-BUSINESS-1579188410',
    ];
    expect(sortPassengers(passengers)).toEqual([
      'Luisa Diaz-BUSINESS-1579188410',
      'Juan Romero-ECONOMY-1579188430',
    ]);
  });
  it('should sort economy by timestamp', () => {
    const passengers = [
      'Juan Romero-ECONOMY-1579188430',
      'Camila Greco-ECONOMY-1579188420',
    ];
    expect(sortPassengers(passengers)).toEqual([
      'Camila Greco-ECONOMY-1579188420',
      'Juan Romero-ECONOMY-1579188430',
    ]);
  });

  it('should solve excersise input', () => {
    const passengers = [
      'Luisa Diaz-BUSINESS-1579188410',
      'Juan Romero-ECONOMY-1579188430',
      'Camila Greco-ECONOMY-1579188420',
      'Mariano Camareli-BUSINESS-1579188440',
    ];
    expect(sortPassengers(passengers)).toEqual([
      'Luisa Diaz-BUSINESS-1579188410',
      'Mariano Camareli-BUSINESS-1579188440',
      'Camila Greco-ECONOMY-1579188420',
      'Juan Romero-ECONOMY-1579188430',
    ]);
  });
});
